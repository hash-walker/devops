# ReactNodeTesting
Sample React and Node/Express project to demonstrate usage of React Test Library and Jest test frameworks.
Article for this can be found here - https://medium.com/@eljamaki01/testing-a-react-node-express-app-with-react-test-library-and-jest-2ac910812c41